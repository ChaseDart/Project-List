﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class MoveCost
    {
        private  int distance; //number of nodes away from the start
        private  int estimate; //estimated cost to the next node
        private  int cellvalue; //Estimate + Distance
        private  int col;
        private  int row;
        private MoveCost parent;

        public  int Distance { get => distance; set => distance = value; }
        public  int Estimate { get => estimate; set => estimate = value; }
        public  int CellValue { get => cellvalue; set => cellvalue = value; }
        public  int Col { get => col; set => col = value; }
        public  int Row { get => row; set => row = value; }
        public MoveCost Parent { get => parent; set => parent = value; }


        //public MoveCost(int col, int row)
        //{
        //    this.Col = Convert.ToInt32(col);
        //    this.Row = Convert.ToInt32(row);
        //}
    }
}
