﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int column_size = 30;
        int row_size = 30;

        MoveCost start = new MoveCost { Col = 15, Row = 3, CellValue = 0 };
        MoveCost target = new MoveCost { Col = 15, Row = 27, CellValue = 0 };
        List<MoveCost> wall = new List<MoveCost>();

        int d = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void PathGridViewer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateGrid();
        }

        private void CreateGrid()
        {
            //setting the open list
            for (int j = 0; j < row_size; j++)
            {
                Grid.Rows.Add();
            }

            //splitting the cells evenly
            foreach (DataGridViewColumn c in Grid.Columns) {
                c.Width = Grid.Width / Grid.Columns.Count;
            }
            foreach (DataGridViewRow r in Grid.Rows) {
                r.Height = Grid.Height / Grid.Rows.Count;
            }

            //Initial Start Node Position
            Grid.Rows[start.Row].Cells[start.Col].Style.BackColor = Color.Red;

            //Initial End Node Position
            Grid.Rows[target.Row].Cells[target.Col].Style.BackColor = Color.YellowGreen;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StartPressed();
        }

        private void StartPressed()
        {
            //Makes sure that only one start position was is on the Grid
            Grid.Rows[Grid.CurrentCell.RowIndex].Cells[Grid.CurrentCell.ColumnIndex].Style.BackColor = Color.Red;
            Grid.Rows[start.Row].Cells[start.Col].Style.BackColor = Color.White;

            //Replaces the Grid
            start.Col = Grid.CurrentCell.ColumnIndex;
            start.Row = Grid.CurrentCell.RowIndex;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            TargetPressed();
        }

        private void TargetPressed()
        {
            //Makes sure that only one end position was is on the Grid
            Grid.Rows[Grid.CurrentCell.RowIndex].Cells[Grid.CurrentCell.ColumnIndex].Style.BackColor = Color.YellowGreen;
            Grid.Rows[target.Row].Cells[target.Col].Style.BackColor = Color.White;

            //Replaces the Grid
            target.Col = Grid.CurrentCell.ColumnIndex;
            target.Row = Grid.CurrentCell.RowIndex;
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Search_Reset();
            AStarDirection();
        }

        //Calculates the Estimate distance between the start and target node
        private int Calculate_Estimate(int StartX, int StartY, int TargetX, int TargetY)
        {
            return Math.Abs(TargetX - StartX) + Math.Abs(TargetY - StartY);
        }

        List<MoveCost> Initial_Location(int CurrentRow, int CurrentCol)
        {
            List<MoveCost> initial_location = new List<MoveCost>();

            initial_location.Add(new MoveCost { Col = CurrentCol + 1, Row = CurrentRow });
            initial_location.Add(new MoveCost { Col = CurrentCol - 1, Row = CurrentRow });
            initial_location.Add(new MoveCost { Col = CurrentCol, Row = CurrentRow + 1 });
            initial_location.Add(new MoveCost { Col = CurrentCol, Row = CurrentRow - 1 });

            return initial_location;

        }

        //A* Shortest Path Algorethem
        private void AStarDirection()
        {
            //Step 1: Create an Open List and a Close List
            var moveCost = new MoveCost();
            var openList = new List<MoveCost>();
            var closeList = new List<MoveCost>();

            //initialising the current node as start
            var current = start;

            //distance
            d = 0;
            
            //Step 2: Add the start to the Open List
            openList.Add(start);

            //Step 3: While Loop
            while(openList.Count > 0)
            {
                //Create Possible next steps to get to the end
                List<MoveCost> initial_location = new List<MoveCost>();

                //finding the lowest costing Node and setting as current Node
                int lowest_est = openList.Min(MoveCost => MoveCost.CellValue);
                int lowest_est_index = openList.FindIndex(MoveCost => MoveCost.CellValue == lowest_est);
                current = openList[lowest_est_index];

                //removing the current Node from the Open List
                openList.RemoveAt(lowest_est_index);

                //setting the Initial nodes
                initial_location = Initial_Location(current.Row, current.Col);

                d++;

                //finding the next step for the shortest path using the initial locations
                foreach (var successor in initial_location)
                {
                    //Giant If statement that stops the next node (initial position) from being the current node
                    if ((successor.Col == current.Col && successor.Row == current.Row) ||                                                   //current node cant be the successor node
                        (closeList.Exists(MoveCost => MoveCost.Col == successor.Col && MoveCost.Row == successor.Row))||                    //successor node cant be on the closeList
                        (wall.Exists(MoveCost => MoveCost.Col == successor.Col && MoveCost.Row == successor.Row))||                         //successor node cant be in a wall
                        (successor.Col >= column_size) || (successor.Row >= row_size) || (successor.Col < 0) || (successor.Row < 0))        //successor node cant be outside the grid
                        continue;

                    //Add the successor node to the open list if it isnt there already
                    if(!openList.Exists(MoveCost => MoveCost.Col == successor.Col && MoveCost.Row == successor.Row))
                    {
                        successor.Distance = d;
                        successor.Estimate = Calculate_Estimate(successor.Col, successor.Row, target.Col, target.Row);
                        successor.CellValue = successor.Distance + successor.Estimate;
                        successor.Parent = current;

                        openList.Add(successor);
                    }
                    else //if the node is already on the open list, compare it to nodes value and substitute if it's higher
                    {
                        int cellvalue = openList.Find(MoveCost => MoveCost.Col == successor.Col && MoveCost.Row == successor.Row).CellValue;
                        if(cellvalue < successor.CellValue)
                        {
                            successor.Distance = d;
                            successor.CellValue = successor.Distance + successor.Estimate;
                            successor.Parent = current;
                        }
                    }
                }

                //Step 4: add current node to the Closelist
                closeList.Add(current);

                //Step 5: break the while loop once CloseList has reach the target
                if (closeList.FirstOrDefault(MoveCost => MoveCost.Col == target.Col && MoveCost.Row == target.Row) != null)
                    break;
            }

            //display where the search was
            int i = 1;
            double closecount = closeList.Count();
            double redvalue;

            foreach (var shortest in closeList)
            {
                redvalue = i / closecount;
                redvalue = redvalue * 255;
                Grid.Rows[shortest.Row].Cells[shortest.Col].Style.BackColor = Color.FromArgb(Convert.ToInt32(redvalue), 0, 255 - Convert.ToInt32(redvalue));
                i = i + 1;
            }

            Grid.Refresh();

            //display the Shortest Path
            while (true)
            {
                Grid.Rows[current.Row].Cells[current.Col].Style.BackColor = Color.Yellow;
                current = current.Parent;
                if (current.Distance == 0)
                break;
            }

            //displays the start and target
            Grid.Rows[start.Row].Cells[start.Col].Style.BackColor = Color.Red;
            Grid.Rows[target.Row].Cells[target.Col].Style.BackColor = Color.YellowGreen;
        }

        //Create walls
        private void CreateWall()
        {
            wall.Add(new MoveCost { Row = Grid.CurrentCell.RowIndex, Col = Grid.CurrentCell.ColumnIndex });
            Grid.Rows[Grid.CurrentCell.RowIndex].Cells[Grid.CurrentCell.ColumnIndex].Style.BackColor = Color.Black;
        }

        private void CreateMaze(int row, int col)
        {
            wall.Add(new MoveCost { Row = row, Col = col });
            Grid.Rows[row].Cells[col].Style.BackColor = Color.Black;
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            Grid_Reset();
            string maze;
            int k = 0;

            maze = "/////////////////////////////" +
                   "/./............././........./." +
                   "/.///////////./././././////./." +
                   "/.../........././././.../.../." +
                   "///././////////./././//././//." +
                   "/././.../....././.../.../....." +
                   "/././//./////././//././//////." +
                   "/./.../....././.../././...../." +
                   "/.///././//././//./././//.///." +
                   "/..././..././....././.../....." +
                   "/./././////././////////./////." +
                   "/././.../.../...../.../...../." +
                   "/./////././//////./././////.//" +
                   "/...../..././.../..././.../..." +
                   "/.///./////./././////./././//." +
                   "/./........././......././.../." +
                   "///.///./////./////////.///./." +
                   "/.../././....././......././..." +
                   "/.///./././////././//.///.///." +
                   "/./....././........./.../.../." +
                   "/./////./././//////.///././//." +
                   "/....././././...../.../././..." +
                   "/.///./././././//.///././././/" +
                   "/./.../././././.../..././.../." +
                   "/././//./././././//////././//." +
                   "/././.../././././.../.../.../." +
                   "/././////.///./././././////./." +
                   "/././.../...../././././..././." +
                   "/././././//////./././././././." +
                   "/./.../.........../..././....." +
                   "//////////////////////////////";
            int mazeindex1;
            int parent = -1;
            for (int i = 0; i < 30; i++)
            {
                for (int j = 0; j < 30; j++)
                {
                    mazeindex1 = maze.IndexOf('/', k);
                    if (mazeindex1 - parent != 0)
                    {
                        CreateMaze(i, j);
                        parent = mazeindex1;
                    }
                    k++;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Grid_Reset();
            string maze;
            int k = 0;

            maze = "............................." +
                   ".............................." +
                   "......./............../......." +
                   "......../............/........" +
                   ".../...../........../...../..." +
                   "..../.....//////////...../...." +
                   "...../................../....." +
                   "....../................/......" +
                   "......./............../......." +
                   "......../............/........" +
                   "......../............/........" +
                   "......../............/........" +
                   "......../............/........" +
                   "......../............/........" +
                   "......../............/........" +
                   "......../............/........" +
                   "......./............../......." +
                   "....../................/......" +
                   "...../................../....." +
                   "..../..................../...." +
                   ".../....................../..." +
                   ".............................." +
                   "........//////////////........" +
                   "......./............../......." +
                   "....../................/......" +
                   "...../................../....." +
                   "..../..................../...." +
                   ".../....................../..." +
                   ".............................." +
                   ".............................." +
                   "..............................";
            int mazeindex;
            int parent = -1;
            for (int i = 0; i < 30; i++)
            {
                for (int j = 0; j < 30; j++)
                {
                    mazeindex = maze.IndexOf('/', k);
                    if (mazeindex - parent != 0)
                    {
                        CreateMaze(i, j);
                        parent = mazeindex;
                    }
                    k++;
                }
            }
        }

        private void Grid_Reset()
        {
            wall.Clear();
            for (int j = 0; j < 30; j++)
            {
                for (int i = 0; i < 30; i++)
                {
                    Grid.Rows[j].Cells[i].Style.BackColor = Color.White;
                }
            }

            Grid.Rows[start.Row].Cells[start.Col].Style.BackColor = Color.Red;
            Grid.Rows[target.Row].Cells[target.Col].Style.BackColor = Color.YellowGreen;
        }

        private void Search_Reset()
        {
            for (int j = 0; j < 30; j++)
            {
                for (int i = 0; i < 30; i++)
                {
                    if (Grid.Rows[j].Cells[i].Style.BackColor == Color.Black)
                        continue;

                    Grid.Rows[j].Cells[i].Style.BackColor = Color.White;
                }
            }

            Grid.Rows[start.Row].Cells[start.Col].Style.BackColor = Color.Red;
            Grid.Rows[target.Row].Cells[target.Col].Style.BackColor = Color.YellowGreen;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Grid_Reset();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Search_Reset();
        }

        bool open = false;

        private void Form1_Activated(object sender, EventArgs e)
        {
            while (open == false)
            {
                // Create a new instance of the Form2 class
                Form2 settingsForm = new Form2();

                // Show the settings form
                settingsForm.Show();
                open = true;
            }
        }

        private void Grid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            CreateWall();
        }
    }
}
